/*var datadata = {
    "page": null,
    "deptlist": [{
        "id": "117",
        "we_id": "1",
        "we_parentid": "0",
        "we_name": "数字星空全体成员",
        "rank": "200",
        "_child": [


        {
            "id": "202167",
            "we_id": "283",
            "we_parentid": "1",
            "we_name": "百会奖励1",
            "rank": "0"
        }, 

        {
            "id": "204243",
            "we_id": "284",
            "we_parentid": "1",
            "we_name": "公开课",
            "rank": "4"
        }, {
            "id": "35305",
            "we_id": "70",
            "we_parentid": "1",
            "we_name": "卡巴斯基VIP",
            "rank": "3000"
        }, 




        {
            "id": "35506",
            "we_id": "71",
            "we_parentid": "1",
            "we_name": "pcstars",
            "rank": "3200",
            "_child": [{
                "id": "125725",
                "we_id": "271",
                "we_parentid": "71",
                "we_name": "测试组",
                "rank": "0"
            }, {
                "id": "35507",
                "we_id": "72",
                "we_parentid": "71",
                "we_name": "人力资源部",
                "rank": "200",
                "_child": [{
                    "id": "35508",
                    "we_id": "73",
                    "we_parentid": "72",
                    "we_name": "法务部",
                    "rank": "200"
                }, {
                    "id": "35509",
                    "we_id": "74",
                    "we_parentid": "72",
                    "we_name": "人事部",
                    "rank": "400"
                }, {
                    "id": "35510",
                    "we_id": "75",
                    "we_parentid": "72",
                    "we_name": "行政部",
                    "rank": "600"
                }]
            }, {
                "id": "35512",
                "we_id": "78",
                "we_parentid": "71",
                "we_name": "财务部",
                "rank": "600",
                "_child": [{
                    "id": "35513",
                    "we_id": "79",
                    "we_parentid": "78",
                    "we_name": "财务部",
                    "rank": "200"
                }, {
                    "id": "35514",
                    "we_id": "80",
                    "we_parentid": "78",
                    "we_name": "商务部",
                    "rank": "400"
                }]
            }, {
                "id": "35515",
                "we_id": "81",
                "we_parentid": "71",
                "we_name": "运维部",
                "rank": "800"
            }, {
                "id": "35525",
                "we_id": "83",
                "we_parentid": "71",
                "we_name": "卡巴365事业部",
                "rank": "1200",
                "_child": [{
                    "id": "35526",
                    "we_id": "98",
                    "we_parentid": "83",
                    "we_name": "卡巴外呼部",
                    "rank": "200"
                }, {
                    "id": "35527",
                    "we_id": "99",
                    "we_parentid": "83",
                    "we_name": "卡巴呼入部",
                    "rank": "400"
                }, {
                    "id": "35528",
                    "we_id": "100",
                    "we_parentid": "83",
                    "we_name": "卡巴管理部",
                    "rank": "600"
                }, {
                    "id": "35529",
                    "we_id": "101",
                    "we_parentid": "83",
                    "we_name": "卡巴市场推广部",
                    "rank": "800"
                }]
            }, {
                "id": "35538",
                "we_id": "86",
                "we_parentid": "71",
                "we_name": "百会事业部",
                "rank": "1800",
                "_child": [{
                    "id": "35539",
                    "we_id": "108",
                    "we_parentid": "86",
                    "we_name": "行业解决方案部",
                    "rank": "200"
                }, {
                    "id": "35540",
                    "we_id": "109",
                    "we_parentid": "86",
                    "we_name": "百会客户管理部",
                    "rank": "400"
                }, {
                    "id": "35541",
                    "we_id": "110",
                    "we_parentid": "86",
                    "we_name": "百会直销部",
                    "rank": "600"
                }, {
                    "id": "35544",
                    "we_id": "111",
                    "we_parentid": "86",
                    "we_name": "百会市场运营部",
                    "rank": "800"
                }, {
                    "id": "36013",
                    "we_id": "119",
                    "we_parentid": "86",
                    "we_name": "百会技术部",
                    "rank": "1000"
                }, {
                    "id": "36014",
                    "we_id": "120",
                    "we_parentid": "86",
                    "we_name": "百会创造者",
                    "rank": "1200"
                }]
            }, {
                "id": "35546",
                "we_id": "87",
                "we_parentid": "71",
                "we_name": "总裁办",
                "rank": "2000"
            }, {
                "id": "35547",
                "we_id": "88",
                "we_parentid": "71",
                "we_name": "渠道部",
                "rank": "2200",
                "_child": [{
                    "id": "131961",
                    "we_id": "273",
                    "we_parentid": "88",
                    "we_name": "渠道直销部",
                    "rank": "200"
                }, {
                    "id": "131963",
                    "we_id": "274",
                    "we_parentid": "88",
                    "we_name": "渠道销售部",
                    "rank": "400"
                }]
            }, {
                "id": "35549",
                "we_id": "89",
                "we_parentid": "71",
                "we_name": "办公逸",
                "rank": "2400",
                "_child": [{
                    "id": "35552",
                    "we_id": "118",
                    "we_parentid": "89",
                    "we_name": "办公逸客服部",
                    "rank": "600"
                }, {
                    "id": "36015",
                    "we_id": "121",
                    "we_parentid": "89",
                    "we_name": "办公逸研发部",
                    "rank": "800"
                }, {
                    "id": "69205",
                    "we_id": "122",
                    "we_parentid": "89",
                    "we_name": "办公逸财务部",
                    "rank": "1000"
                }, {
                    "id": "69207",
                    "we_id": "123",
                    "we_parentid": "89",
                    "we_name": "办公逸产品部",
                    "rank": "1200"
                }, {
                    "id": "131965",
                    "we_id": "272",
                    "we_parentid": "89",
                    "we_name": "办公逸市场运营部",
                    "rank": "1400"
                }]
            }, {
                "id": "132005",
                "we_id": "275",
                "we_parentid": "71",
                "we_name": "测试组2",
                "rank": "2600"
            }, {
                "id": "135835",
                "we_id": "277",
                "we_parentid": "71",
                "we_name": "测试组3",
                "rank": "2800"
            }, {
                "id": "211343",
                "we_id": "282",
                "we_parentid": "71",
                "we_name": "测试组4",
                "rank": "3000"
            }]
        },


         {
            "id": "121011",
            "we_id": "125",
            "we_parentid": "1",
            "we_name": "办公逸双11管理员",
            "rank": "3600",
            "_child": [{
                "id": "121023",
                "we_id": "137",
                "we_parentid": "125",
                "we_name": "溢柯园艺",
                "rank": "1400",
                "_child": [{
                    "id": "198411",
                    "we_id": "278",
                    "we_parentid": "137",
                    "we_name": "后台通讯录",
                    "rank": "200",
                    "_child": [{
                        "id": "198413",
                        "we_id": "279",
                        "we_parentid": "278",
                        "we_name": "后台通讯录",
                        "rank": "200",
                        "_child": [{
                            "id": "198415",
                            "we_id": "280",
                            "we_parentid": "279",
                            "we_name": "后台通讯录",
                            "rank": "200",
                            "_child": [{
                                "id": "198417",
                                "we_id": "281",
                                "we_parentid": "280",
                                "we_name": "后台通讯录后台通讯录",
                                "rank": "200"
                            }]
                        }]
                    }]
                }]
            }]
        }



        ]
    }],
    "countlist": {
        "202167": {
            "count": 0,
            "department_id": "202167"
        },
        "125725": {
            "count": "1",
            "department_id": "125725"
        },
        "204243": {
            "count": 0,
            "department_id": "204243"
        },
        "35526": {
            "count": "1",
            "department_id": "35526"
        },
        "131961": {
            "count": "1",
            "department_id": "131961"
        },
        "198413": {
            "count": 0,
            "department_id": "198413"
        },
        "35513": {
            "count": "2",
            "department_id": "35513"
        },
        "198411": {
            "count": 0,
            "department_id": "198411"
        },
        "198415": {
            "count": 0,
            "department_id": "198415"
        },
        "198417": {
            "count": 0,
            "department_id": "198417"
        },
        "35508": {
            "count": "1",
            "department_id": "35508"
        },
        "35507": {
            "count": "6",
            "department_id": "35507"
        },
        "35539": {
            "count": "2",
            "department_id": "35539"
        },
        "131963": {
            "count": "2",
            "department_id": "131963"
        },
        "35540": {
            "count": "12",
            "department_id": "35540"
        },
        "35509": {
            "count": "2",
            "department_id": "35509"
        },
        "35514": {
            "count": "2",
            "department_id": "35514"
        },
        "35527": {
            "count": "6",
            "department_id": "35527"
        },
        "35528": {
            "count": "2",
            "department_id": "35528"
        },
        "35541": {
            "count": "22",
            "department_id": "35541"
        },
        "35510": {
            "count": "2",
            "department_id": "35510"
        },
        "35512": {
            "count": "4",
            "department_id": "35512"
        },
        "35552": {
            "count": "6",
            "department_id": "35552"
        },
        "35515": {
            "count": "2",
            "department_id": "35515"
        },
        "36015": {
            "count": "23",
            "department_id": "36015"
        },
        "35544": {
            "count": "6",
            "department_id": "35544"
        },
        "35529": {
            "count": "4",
            "department_id": "35529"
        },
        "36013": {
            "count": "17",
            "department_id": "36013"
        },
        "69205": {
            "count": "1",
            "department_id": "69205"
        },
        "35525": {
            "count": "13",
            "department_id": "35525"
        },
        "36014": {
            "count": "2",
            "department_id": "36014"
        },
        "69207": {
            "count": "2",
            "department_id": "69207"
        },
        "121023": {
            "count": 0,
            "department_id": "121023"
        },
        "131965": {
            "count": "4",
            "department_id": "131965"
        },
        "35538": {
            "count": "61",
            "department_id": "35538"
        },
        "35546": {
            "count": "3",
            "department_id": "35546"
        },
        "35547": {
            "count": "6",
            "department_id": "35547"
        },
        "35549": {
            "count": "36",
            "department_id": "35549"
        },
        "132005": {
            "count": 0,
            "department_id": "132005"
        },
        "135835": {
            "count": "1",
            "department_id": "135835"
        },
        "35305": {
            "count": "6365",
            "department_id": "35305"
        },
        "211343": {
            "count": "1",
            "department_id": "211343"
        },
        "35506": {
            "count": "134",
            "department_id": "35506"
        },
        "121011": {
            "count": 0,
            "department_id": "121011"
        }
    }
};
*/


(function($){
	var $swiperWrap = $('#swiperWrap'),
		$headerSearch = $('#headerSearch'),
		$letterShow = $('#letterShow'),
		$letterWrap = $('#letterWrap'),
		$letterWrapMask = $('#letterWrapMask'),
		$clearBtn = $('#clearBtn'),
		$searchText = $('#searchText'),
		$searchBtn = $('#searchBtn'),
		$departmentList = $('#departmentList'),
		$normalList = $('#normalList'),
		$selectSureBtn = $('#selectSureBtn'),
		$allList = $('#allList'),
		$selectWrap = $('#selectWrap'),
		$searchList = $('#searchList'),
		$parentsList = $('#parentsList'),
		$selectContainer = $('#selectContainer'),
		$swiperFixed = $('#swiperFixed'),
		$loading = $('#ajaxLoading'),
		$selectGoTop = $('#selectGoTop'),
		_Swiper = null,
		_Type = null,
		normalUserDroploadObj = stafflistDroploadObj = allUserDroploadObj = null,
		_Kind = 0;
	window.YiSelect = {
		init : function(type) {
			//_Type = this.getUrlParam()['type'];
			_Type = type;
			this.bindEvent();
		},
		lazyload : function(){
    		$selectWrap.find('img').lazyload();
    	},
		searchAll : function(text){
			var _this = this;
			$.ajax({
				url : '/address/staff/search',
				type : 'get',
				data : {
				    aid : _aid,
				    action : "paging",
				    search : text,
				    appstore_id : window.__appstoreid,
				    page : 0
				},
				beforeSend : function(){
					$loading.show();
				},
				dataType : 'json',
				success : function(data){
					$loading.hide();
					if(data.stafflist){
						var html ='';
						$.each(data.stafflist,function(i,e){
							var ddStr = '',
								dt = '<dt>'+i.toUpperCase()+'</dt>';
							$.each(e,function(m,n){
								ddStr += '<dd data-uid="'+n.id+'"><em></em><img data-src="'+((n.we_avatar!="")?n.we_avatar:defaultAvatar)+'" src="'+defaultAvatar+'" />'+n.we_name+'</dd>';
							});
							html += '<dl>'+dt+ddStr+'</dl>';
						});
						if(html){
							$searchList.children('span').remove();
						};
						//console.info(data.stafflist,html==false)
						$searchList.html(html);
						_this.userSelect();
						_this.lazyload();
					}else{
						$searchList.html('<span>暂无数据...</span>');
					};
					
				}
			});	
		},
		
		//搜索
		searchRender : function(){
			var _this = this;
			$searchBtn.unbind('click').on('click',function(){
				//1 ：常用  2:全部  3; 部门
				$.each($headerSearch.find('li'),function(i,e){
					if($(e).hasClass('cur')){
						$(e).removeClass('cur').addClass('on');
					};
				});
				//$searchList.html('<span>对不起，搜索结果为空!</span>').show().siblings('section').hide();
				$searchList.html('').show().siblings('section').hide();
				/*if(_Kind==1){
					_this.renderNormalUser($.trim($searchText.val()),0,$searchList)
				}else*/
				if(_Kind==1 || _Kind==2 || _Kind==3){
					_this.searchAll($.trim($searchText.val()));
					if(_Kind==3){
						$selectSureBtn.show()
					};
				};
				
			});
		},
		
		//下拉刷新列表
		
		normalUserPage :　2 ,
		normalUserDropload : false,
		normalUserScroll : function(){
			var _this = this;
			normalUserDroploadObj = $normalList.dropload({
				scrollArea : window,
			    domUp : {
			        domClass   : 'dropload-up',
			        domRefresh : '<div class="dropload-refresh">↓下拉刷新</div>',
			        domUpdate  : '<div class="dropload-update">↑释放更新</div>',
			        domLoad    : '<div class="dropload-load"><span class="loading"></span>加载中...</div>'
			    },
			    loadDownFn : function(o){
			        _this.renderNormalUser('',_this.normalUserPage,$normalList);
			        _this.normalUserPage++;
			        o.resetload();
			    }
			});
			_this.normalUserDropload = true;
		},
		
		
		allUserPage :　2 ,
		allUserDropload : false,
		allUserScroll : function(){
			var _this = this;
			window.allUserDroploadObj = $allList.dropload({
				scrollArea : window,
			    domUp : {
			        domClass   : 'dropload-up',
			        domRefresh : '<div class="dropload-refresh">↓下拉刷新</div>',
			        domUpdate  : '<div class="dropload-update">↑释放更新</div>',
			        domLoad    : '<div class="dropload-load"><span class="loading"></span>加载中...</div>'
			    },
			    loadDownFn : function(o){
			        _this.renderAllUser(_this.allUserPage);
			        _this.allUserPage++;
			        o.resetload();
			    }
			});
			_this.allUserDropload = true;
		},
		
		
		renderSwiper : function(){
			_Swiper = new Swiper('.swiper-container', {
		        slidesPerView: 'auto',
		        centeredSlides : false,
		        slidesPerView:'auto',
		        speed : 1000, //初始值为500
		        spaceBetween: 5
		    });	   
		},
		
		renderData : function(){
			var arr = [];
			$.each($swiperWrap.find('div.swiper-slide'),function(i,e){
				var o = {};
				o.name = $(e).data('name');
				o.src  = $.trim($(e).children('img').attr('src'));
				o.uid  = $(e).data('uid');
				arr.push(o);
			});
			//console.info(arr);
			//$swiperWrap.children('input[type="hidden"]').val(arr.join(','));
			return arr;
		},
		
		//渲染常用联系人 
		renderNormalUser:function(searchText,page,o){
			//alert('渲染常用联系人');
			var _this = this;
			$.ajax({
				url : '/address/staff/contactlist',
				type : 'get',
				data : {
				    aid : _aid,
				    action : "paging",
				    search : searchText,
				    page : page
				},
				dataType : 'json',
				beforeSend : function(){
					$loading.show();
				},
				success : function(data){
					//console.info(data)
					$loading.hide();
					if(data.stafflist){
						var html ='';
						$.each(data.stafflist,function(i,e){
							var ddStr = '',
								dt = '<dt>'+i.toUpperCase()+'</dt>';
							$.each(e,function(m,n){
								ddStr += '<dd data-uid="'+n.id+'"><em></em><img data-src="'+((n.we_avatar!="")?n.we_avatar:defaultAvatar)+'" src="'+defaultAvatar+'" />'+n.we_name+'</dd>';
							});
							html += '<dl>'+dt+ddStr+'</dl>';
						});
						if(html){o.children('span').remove();};
						o.append(html);
						_this.userSelect();
						_this.lazyload();
						if(normalUserDroploadObj){
							normalUserDroploadObj.lock();
						};
					};
					
				}
			});	
		},
		
		//渲染全部联系人
		renderAllUser:function(page){
			//alert('渲染全部联系人');
			var _this = this;
			$.ajax({
				url : '/address/staff/list',
				type : 'get',
				data : {
				    aid : _aid,
				    action : "paging",
				    appstore_id : window.__appstoreid,
				    page : page
				},
				beforeSend : function(){
					$loading.show();
				},
				dataType : 'json',
				success : function(data){
					//console.info(data)
					$loading.hide();
					if(data.stafflist){
						var html ='';
						$.each(data.stafflist,function(i,e){
							var ddStr = '',
								dt = '<dt>'+i.toUpperCase()+'</dt>';
							$.each(e,function(m,n){
								//console.info(n.we_avatar?n.we_avatar:defaultAvatar);
								//console.info(2323)
								ddStr += '<dd data-uid="'+n.id+'"><em></em><img data-src="'+((n.we_avatar!="")?n.we_avatar:defaultAvatar)+'" src="'+defaultAvatar+'" />'+n.we_name+'</dd>';
							});
							html += '<dl>'+dt+ddStr+'</dl>';
						});
						if(html){$allList.children('span').remove();};
						$allList.append(html);
						_this.userSelect();
						_this.lazyload();
						if(allUserDroploadObj){
							allUserDroploadObj.lock();
						};
						
					};
				}
			});
		},

		
		//渲染部门
		renderDepartment : function(){
			//alert('渲染部门');
			var _this = this;
			$.ajax({
				url : '/address/staff/deptlist',
				type : 'get',
				data : {
				    aid : _aid,
				    appstore_id : window.__appstoreid,
				    action : "paging"
				},
				beforeSend : function(){
					$loading.show();
				},
				dataType : 'json',
				success : function(data){
					//console.info(data);
					//var data= datadata;
					$loading.hide();
					$departmentList.html('');
					if(data.deptlist && data.countlist){
						function renderUl(result,list){
							//if((result._child&&result._child.length>0)||result.length>0){
							if((result['_child'] && result['_child'].length>0)){
								list.append("<ul></ul>");
								list = list.find("ul");
								$.each(result['_child'],function(i,e){
								    //console.info(i);
								    (function(j){
                                        //console.info(e.id)
                                        var partmentId = '',
                                            num = '';   
                                        $.each(data.countlist,function(m,n){
                                            if(e.id==m){
                                                num = n.count?n.count:'';
                                                partmentId = n['department_id']?n['department_id']:'';
                                                return false;
                                            }; 
                                        });
                                        
                                        //console.info(partmentId,num);
                                        list.append('<li><a href="javascript:void(0)" data-num="'+num+'" data-pid="'+partmentId+'">'+e.we_name+'</a></li>');    
                                        
    
                                        //list.css('background','#f00');
                                        if(e['_child'] && e['_child'].length>0){
                                            //console.info(e,$(list.children('li')[0]),j)
                                            renderUl(e,$(list.children('li')[j]));
                                        };
								    })(i);
								});	
							};
						};
						
						renderUl(data.deptlist[0],$departmentList);
						_this.departmentMethod();
					};
				}
			});
		},
		
		
		
		departmentMethod : function(){

			var _this = this;

			//部门多级下拉菜单
			$.each($departmentList.find('li'),function(i,e){
				if($(e).children('ul').length){
					$(e).children('a').append('<em></em>');
				};

				
				if($(e).children('a') && $(e).children('a').data('num')){	
					$(e).children('a').append('<i data-num="'+$(e).children('a').data('num')+'">'+$(e).children('a').data('num')+'</i>');
					$(e).children('a').append('<span></span>');
				};

			});


			
			
			$departmentList.find('li a').unbind('click').on('click',function(e){
				$(this).parent().children('ul').toggle();
				$(this).toggleClass('cur');
				e.preventDefault();
			});
			
			
			$departmentList.find('li a > i').unbind('click').on('click',function(e){
				if(!$(this).data('num')){
					return false;
				};
				_this.stafflistAjaxPage = 2;
				_this.staffParmentId = $.trim($(this).parents('a').data('pid'));

				
				_this.stafflistAjax(_aid,_this.staffParmentId,1);


				$headerSearch.find('li').eq(2).removeClass('cur').addClass('on');
				$selectSureBtn.show();
				$parentsList.html('').show();
				$departmentList.hide();
				//$departmentList.children('ul').hide();
				e.stopPropagation();
			});
		},

		stafflistAjaxPage : 2,
		staffParmentId : null ,
		stafflistDropload : false,
		stafflistAjaxScroll : function(){
			var _this = this;
			window.stafflistDroploadObj = $parentsList.dropload({
				scrollArea : window,
			    domUp : {
			        domClass   : 'dropload-up',
			        domRefresh : '<div class="dropload-refresh">↓下拉刷新</div>',
			        domUpdate  : '<div class="dropload-update">↑释放更新</div>',
			        domLoad    : '<div class="dropload-load"><span class="loading"></span>加载中...</div>'
			    },
			    loadDownFn : function(o){
			        _this.stafflistAjax(_aid,_this.staffParmentId,_this.stafflistAjaxPage);
			        _this.stafflistAjaxPage++;
			        o.resetload();
			    }
			});
			_this.stafflistDropload = true;
		},


		stafflistAjax : function(aid,pid,page){
			var _this = this;
			$.ajax({
				url : '/address/staff/stafflist',
				type : 'get',
				beforeSend : function(){
					$loading.show();
				},
				data : {
				    aid : aid,
				    deptid: pid,
				    appstore_id : window.__appstoreid,
				    action : "paging",
				    page : page
				},
				dataType : 'json',
				success : function(data){
					//console.info(1111,data);
					$loading.hide();
					if(data.stafflist){
						var html ='';
						$.each(data.stafflist,function(i,e){
							var ddStr = '',
								dt = '<dt>'+i.toUpperCase()+'</dt>';
							$.each(e,function(m,n){
								ddStr += '<dd data-uid="'+n.id+'"><em></em><img data-src="'+((n.we_avatar!="")?n.we_avatar:defaultAvatar)+'" src="'+defaultAvatar+'" />'+n.we_name+'</dd>';
							});
							html += '<dl>'+dt+ddStr+'</dl>';
						});

						if(html){
							$parentsList.append(html);
						};
						
						/*else{
							$parentsList.children('span').show();
						};*/

						_this.userSelect();
						_this.lazyload();
						
						if(stafflistDroploadObj){
							stafflistDroploadObj.lock();
						}
						
						
					};

				}
			});
		},
		
		
		//单选dd事件绑定
		userSelect : function(){
			var _this = this;
			$selectWrap.find('dd').unbind('click').on('click',function(){
				var _thiz = this;
				
				if(_Type==0){ //单选
					$(this).parents('section').siblings('section').find('dd').removeClass('cur');
					$(this).siblings().removeClass('cur');
					$(this).parents('dl').siblings().find('dd').removeClass('cur');
					$(this).toggleClass('cur');
					//console.info(this)
					if($(this).hasClass('cur')){ //选中
						//alert(111)
						$swiperWrap.find('.swiper-wrapper').html('').append('<div class="swiper-slide" data-uid="'+$.trim($(this).data('uid'))+'" data-name="'+$(this).text()+'"><img src="'+$(this).children('img').attr('src')+'" />');
						$swiperFixed.show();
						$selectContainer.css({'padding-top':'65px'});
						//_this.swiperImgClick();
					}else{ //取消选中
						$swiperWrap.find('.swiper-wrapper').html('');
						$swiperFixed.hide();
						$selectContainer.css({'padding-top':'0'});
					};
					
				}else{ //多选
					
					$(this).toggleClass('cur');
					
					var has = false;
					if($(this).hasClass('cur')){ //选中
						$.each($swiperWrap.find('.swiper-wrapper > .swiper-slide'),function(i,e){
							if($(e).data('uid')==$(_thiz).data('uid')){
								has = true;
							};
						});
						//console.info(has);
						if(!has){
							$swiperWrap.find('.swiper-wrapper').append('<div class="swiper-slide" data-uid="'+$.trim($(this).data('uid'))+'" data-name="'+$(this).text()+'"><img src="'+$(this).children('img').attr('src')+'" />');
						};
						$swiperFixed.show();
						$selectContainer.css({'padding-top':'65px'});
						//_this.swiperImgClick();
					}else{ //取消选中
						var _uid = $(this).data('uid');
						$.each($swiperWrap.find('.swiper-wrapper > .swiper-slide'),function(i,e){
							if($(e).data('uid')==_uid){
								$(e).remove();
							};
							if(!$swiperWrap.find('.swiper-wrapper > .swiper-slide').length){
								$swiperFixed.hide();
								$selectContainer.css({'padding-top':'0'});
							};
						});
					};
				};
				_this.swiperImgClick();
				_Swiper.onResize();
				
			});
		},
		
		
		
		getUrlParam:function(url) {
			url = url || window.location.href;
			var objRequest = new Object();
			if (url.indexOf("?") != -1) {
				url = url.split("?")[1];
				var strArr = url.split("&");
				for (var i = 0; i < strArr.length; i ++) {
					objRequest[strArr[i].split("=")[0]] = decodeURI((strArr[i].split("=")[1]));
				}
			}
			return objRequest;
		},
		
		tab : function(){
			var _this = this;
			$headerSearch.find('ul > li').unbind('click').on('click',function(){
				$searchList.hide();
				if($(this).hasClass('cur')){
					return false;
				};
				var index = $(this).index();
				$(this).addClass('cur').siblings().removeClass('cur').removeClass('on');
				if(index==0){
					$normalList.show();
					$allList.hide();
					$departmentList.hide();
					$selectSureBtn.show();
					$parentsList.hide();
					if(!$(this).data('visited')){ //渲染常用联系人
						_this.renderNormalUser('',1,$normalList);
						$(this).data('visited',1);
					};
					_Kind = 1;
				}else if(index==1){
					$allList.show();
					$normalList.hide();
					$departmentList.hide();
					$selectSureBtn.show();
					$parentsList.hide();
					if(!$(this).data('visited')){ //渲染全部联系人
						_this.renderAllUser(1);
						$(this).data('visited',1);
					};
					_Kind = 2;
				}else{
					$allList.hide();
					$normalList.hide();
					$departmentList.html('').show();
					$selectSureBtn.hide();
					_this.renderDepartment(); //渲染全部联系人
					_Kind = 3;
					//$parentsList.html('<span>对不起，搜索结果为空!</span>').hide();
					$parentsList.hide();
				};
				//console.info(index);
								
			}).eq(0).trigger('click');
		},
		
		
		swiperImgClick : function(){
			//alert(3434)
			var _this = this;
			this.renderSwiper();
			$swiperWrap.find('.swiper-wrapper img').unbind('click').on('click',function(){
				//console.info($(this).parents('.swiper-wrapper').children('.swiper-slide').length)
				$(this).parents('.swiper-slide').remove();
				if(!$swiperWrap.find('.swiper-wrapper > .swiper-slide').length){
					$swiperFixed.hide();
					$selectContainer.css({'padding-top':'0'});
				};
				//下面列表联动
				if(_Type=="0"){
					$selectWrap.find('dd').removeClass('cur');
				}else{ //多选
					//遍历
					var _id = $(this).parents('div').data('uid');
					$.each($selectWrap.find('dd'),function(i,e){
						if($(e).data('uid')==_id){
							$(e).removeClass('cur');
						}
					});
				};
				_Swiper.onResize();
			});
		},
		
		
		//关闭弹层时清除所有状态
		resetCloseLayer : function(){
			$headerSearch.find('ul > li').removeClass('cur').removeClass('on');
			$headerSearch.find('ul > li').data('visited',0);
			$selectWrap.children('section').html('<span>暂无数据...</span>');
			$swiperWrap.find('.swiper-wrapper').html('');
			$swiperFixed.hide();
			$selectContainer.css({'padding-top':'0'});
			this.stafflistAjaxPage = this.normalUserPage = this.allUserPage = 2;
			$(window).unbind('scroll');
			normalUserDroploadObj = allUserDroploadObj = stafflistDroploadObj = null;
		},
		
		bindEvent : function(){
			var _this = this;
			//location.reload(true)
			
			//this.renderSwiper();
			
			//点击取消按钮
			$selectSureBtn.find('li').eq(0).children('a').unbind('click').on('click',function(e){		
				//console.info(1111,$(top.document.body).find('.plug-select').length)
				window.__appstoreid = 0;
				var _body = $(top.document.body);
				//_body.removeClass('hideStyle');
				_body.find('.plug-select').removeClass('selected');
				_body.find('#selectContainer').hide();
				$selectGoTop.hide();
				$selectSureBtn.hide();
				_this.resetCloseLayer();
				$(window).scrollTop(window._scrollTopVal);
				e.preventDefault();
			});
		
		
			//点击确认按钮
			$selectSureBtn.find('li').eq(1).children('a').unbind('click').on('click',function(e){
				//console.info(_this.renderData());
				window.__appstoreid = 0;
				var arr = _this.renderData();
				if(!arr.length){
					YI.alert({
						msg : '请选择联系人'
					});
					return false;
				};
				$(window).scrollTop(window._scrollTopVal);


				$selectGoTop.hide();
				var _body = $(top.document.body);
				//_body.removeClass('hideStyle');
				$selectSureBtn.hide();
				top.renderContactList(_this.renderData());
				_body.find('#selectContainer').hide();
				_this.resetCloseLayer();
				e.preventDefault();
			});
		
			//tab初始化
			this.tab();
			
			//字母
			$letterShow.on('click',function(){
				var _top = $(this).offset().top;
				$letterWrap.css({
					top : _top+32
				});
				$letterWrapMask.show();
				$letterWrap.show();
				
				
				$.each($headerSearch.find('li'),function(i,e){
					if($(e).hasClass('cur')){
						$(e).removeClass('cur').addClass('on');
					};
				});
				/*if($headerSearch.find('li').eq(2).hasClass('cur')){
					$headerSearch.find('li').eq(2).removeClass('cur').addClass('on');
				};*/
				
			});
			$letterWrapMask.unbind('click').on('click',function(){
				$letterWrapMask.hide();
				$letterWrap.hide();
			});
			
			$letterWrap.find('ul > li > a > em').unbind('click').on('click',function(){
				//$searchList.html('<span>对不起，搜索结果为空!</span>').show().siblings('section').hide();
				$searchList.show().siblings('section').hide();
				$letterWrap.hide();
				$letterWrapMask.hide();
				
				_this.searchAll($.trim($(this).html()));
			});
			

			
			//搜索框交互
			$searchText.on('keyup',function(){
				if($.trim($(this).val())){
					$clearBtn.show();
					$letterShow.hide();
					$searchBtn.show();
				}else{
					$clearBtn.hide();
					$letterShow.show();
					$searchBtn.hide();
				};
			});
			$clearBtn.unbind('click').on('click',function(){
				$searchText.val('');
				$(this).hide();
				$searchBtn.hide();
				$letterShow.show();
			});
			//渲染高度
			/*$selectWrap.children('section').css({
				height : $(window).height() - $headerSearch.height() - 50,
				border: '1px solid #6c0',
				'overflow-x':'hidden!important',
				'overflow-y':'scroll!important'
			});*/
			
			//滚到页面底部时绑定下拉刷新效果
			this.windowScroll();
			
			//搜索
			this.searchRender();
			
			
			//返回顶部
			$selectGoTop.on('click',function(){
				scrollGoTop();
			});

		
		},
		
		windowScroll:function(){
			var _this = this;
			
			if(!_this.normalUserDropload){		
				_this.normalUserScroll();
			};
			if(!_this.allUserDropload){
				_this.allUserScroll();
			};
			if(!_this.stafflistDropload){
				_this.stafflistAjaxScroll();
			};
			
			$(window).unbind('scroll').bind('scroll',function(){
				
				var selectContainerHeight = $selectContainer.height(),
					windowHeight= $(window).height(),
					scrollTop = $(window).scrollTop();
				//console.info(selectContainerHeight-windowHeight-scrollTop);
				if(selectContainerHeight-windowHeight-scrollTop<5){
					
					//console.info(normalUserDroploadObj,allUserDroploadObj,stafflistDroploadObj);
					
					if(normalUserDroploadObj){
						normalUserDroploadObj.unlock();
					};
					if(allUserDroploadObj){
						allUserDroploadObj.unlock();
					};
					if(stafflistDroploadObj){
						stafflistDroploadObj.unlock();
					};
					
					if(!_this.normalUserDropload){		
						_this.normalUserScroll();
					};
					if(!_this.allUserDropload){
						_this.allUserScroll();
					};
					if(!_this.stafflistDropload){
						_this.stafflistAjaxScroll();
					};
					//$(window).scroll($(window).scroll()-1);
				};
				_this.lazyload();
				
				if(scrollTop>148){
					//console.info(scrollTop);
					$selectGoTop.css('display','block');
				}else{
					$selectGoTop.css('display','none');
				};
				
				
			});
		}
		
	};
	/*$(function() {
		YiSelect.init();
	});*/
	
	
})(Zepto);

window.scrollGoTop = function(acceleration, time) {
    acceleration = acceleration || 0.1;
    time = time || 16; //原来是16
    var x1 = 0;
    var y1 = 0;
    var x2 = 0;
    var y2 = 0;
    var x3 = 0;
    var y3 = 0;
    if (document.documentElement) {
        x1 = document.documentElement.scrollLeft || 0;
        y1 = document.documentElement.scrollTop || 0;
    }
    if (document.body) {
        x2 = document.body.scrollLeft || 0;
        y2 = document.body.scrollTop || 0;
    }
    var x3 = window.scrollX || 0;
    var y3 = window.scrollY || 0;
    // 滚动条到页面顶部的水平距离
    var x = Math.max(x1, Math.max(x2, x3));
    // 滚动条到页面顶部的垂直距离
    var y = Math.max(y1, Math.max(y2, y3));
    // 滚动距离 = 目前距离 / 速度, 因为距离原来越小, 速度是大于 1 的数, 所以滚动距离会越来越小
    var speed = 1 + acceleration;
    window.scrollTo(Math.floor(x / speed), Math.floor(y / speed));
    // 如果距离不为零, 继续调用迭代本函数
    if (x > 0 || y > 0) {
        var invokeFunction = "scrollGoTop(" + acceleration + ", " + time + ")";
        window.setTimeout(invokeFunction, time);
    }
};
	